

export const Usuarios = () => {
  return (
    <div className="container">
        <h4 className="text-center py-5">Usuarios</h4> 
    </div>
  )
}
