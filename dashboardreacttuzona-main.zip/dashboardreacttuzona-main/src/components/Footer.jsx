

const Footer = () => {
  return (
    <div className="bg-dark-subtle text-center p-3 mt-4">
        <h5 className="py-3">Footer</h5>
        <p>© 2025 Company, Inc. AR Sistema.</p>
    </div>
  )
}

export default Footer