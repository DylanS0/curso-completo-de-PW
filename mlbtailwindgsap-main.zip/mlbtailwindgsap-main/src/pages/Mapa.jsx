

const Mapa = () => {
  return (
    <div>Mapa</div>
  )
}

export default Mapa