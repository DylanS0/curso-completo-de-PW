

const Estadisticas = () => {
  return (
    <div>Estadisticas</div>
  )
}

export default Estadisticas