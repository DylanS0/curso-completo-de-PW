

const Comparador = () => {
  return (
    <div>Comparador</div>
  )
}

export default Comparador